<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package lubvi
 */

?>

<footer>
        <div class="footer">
            <h6>Copyright @ 2019, OLga Furtuna</h6>
        </div>

    </footer>
</body>

</html>