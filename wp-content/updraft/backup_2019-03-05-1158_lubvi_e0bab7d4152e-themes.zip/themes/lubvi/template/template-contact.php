<?php
/**
* Template Name: Contact
*
* @package lubvi
* @since lubvi 1.0
*/
?>
<?php get_header(); ?>

<!DOCTYPE HTML>
<html lang="eng">
<body>
     <!--contact-->
    <div class="container-fluid">
        <div class="row text-center alert">
            <div class="col-12">
                <h1 class="display-4"><?php the_field('title_contact'); ?></h1>
            </div>
        </div>
        <div class="row contact">
            <?php
            $contact_block = get_field('contact_block');	
            if( $contact_block): ?>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-6 col-xl-6 contact-col-1" id="contact_block">
                <img src="/wp-content/themes/lubvi/img/contact/background.jpg" />
                <div class="contact-text">
                    <span>
                        <h3><?php echo $contact_block['info'];?></h3>
                        <p><?php echo $contact_block['phone'];?></p>
                        <p><?php echo $contact_block['mail'];?></p>
                        <p><?php echo $contact_block['address'];?></p>
                    </span>
                </div>
            </div>
            <?php endif; ?> 

            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-6 col-xl-6  contact-col-2">
                <div class="contact-col-2-back">
                    <h1>Send me a message</h1>
                    <form>
                        <div class="form-group">
                            <input type="text" class="form-control" id="inputName" placeholder="Your name">
                        </div>

                        <div class="form-group">
                        <input type="email" class="form-control" id="inputEmail" placeholder="Email">
                        </div>

                        <div class="form-group">
                            <input type="number" class="form-control" id="inputNumber" placeholder="Phone number">
                        </div>

                        <div class="form-row">
                            <div class="form-group">
                                <input type="date" class="form-control" id="inputDate" placeholder="Event date">
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control" id="inputLocation" placeholder="Event location">
                            </div>
                        </div>

                        <div class="form-group">
                            <textarea class="form-control" id="inputMessage" rows="5" placeholder="Message"></textarea>
                        </div>

                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" id="agreement">
                            <label class="form-check-label" for="agreement">
                                I agree my personal data to be processed *
                            </label>
                        </div>
                        <a href="#"><button type="submit" class="btn btn-sendmes btn-primary btn-lg" type="button">Send message</button></a> 


                    </form>
                </div>
            </div>
        </div>
    </div>

</body>

</html>
   

<?php get_footer(); ?>
