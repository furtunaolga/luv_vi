<?php
/**
* Template Name: Portfolio
*
* @package lubvi
* @since lubvi 1.0
*/
?>

<?php get_header(); ?>
<!DOCTYPE HTML>
<html lang="eng">
<body>
    <!--portfolio page-->
    <div class="container-fluid">
        <div class="row text-center alert">
            <div class="col-12">
                <h1 class="display-4">Portfolio</h1>
            </div>
        </div>
        <div class="row portfolio btn-container">
            <div id="myBtnContainer" class="btn-port-container">
                <a class="btn-port active" onclick="filterSelection('all')"> Show all</a>
                <a class="btn-port" onclick="filterSelection('nature')"> Nature</a>
                <a class="btn-port" onclick="filterSelection('cars')"> Cars</a>
                <a class="btn-port" onclick="filterSelection('family')"> Family</a>
            </div>
        </div>
        <div class="row portfolio">

            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4 col-xl-4 column family">
                <img src="/wp-content/themes/lubvi/img/portfolio/1.jpg" />
            </div>

            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4 col-xl-4 column nature">
                <img src="/wp-content/themes/lubvi/img/portfolio/4.jpg" alt="Nature" />
            </div>

            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4 col-xl-4 column cars">
                <img src="/wp-content/themes/lubvi/img/portfolio/7.jpg" />
            </div>

            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4 col-xl-4 column family">
                <img src="/wp-content/themes/lubvi/img/portfolio/2.jpg" />
            </div>

            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4 col-xl-4 column nature">
                <img src="/wp-content/themes/lubvi/img/portfolio/5.jpg" alt="Nature" />
            </div>

            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4 col-xl-4 column cars">
                <img src="/wp-content/themes/lubvi/img/portfolio/8.jpg" />
            </div>

        </div>
</body>

</html>
   

<?php get_footer(); ?>
